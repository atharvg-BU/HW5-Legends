package MonstersHeroesGame;

import Parent.GamePiece;

public class MarketPlacePiece extends GamePiece {
    //   Class to store information on the immovable space piece marked by '$'
    public MarketPlacePiece(String icon) {
        super(icon);
    }
}
