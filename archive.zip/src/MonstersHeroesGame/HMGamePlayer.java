package MonstersHeroesGame;

import MonstersHeroesGame.Data.MainData.*;
import Parent.GameMove;
import Parent.GameUser;

import java.util.*;

public class HMGamePlayer extends GameUser {
    public List<HMChosenHero> chosenHeroes;
    public Weapon oneHand;
    public Armory otherHand;
    public boolean quit;
    private HMGamePrinter printer;
    public List<String> defeatedMonsters;
    public MarketSpaceDealing market;
    public HMGamePlayer(String username, List<HMChosenHero> chosenHeroes, Weapon initialWeapon) {
        super(username);
        this.chosenHeroes = chosenHeroes;
        this.quit = false;
        this.defeatedMonsters = new ArrayList<>();
        printer=new HMGamePrinter();
        chosenHeroes.get(0).weapons.add(initialWeapon);
    }
    /*
    Input: N/A
    Outputs: N/A
    Function: Function to enable hero to take their turn by either moving their player/consuming portion or seeing their stats
     */
    public GameMove takeTurn() {
        HMGameMove move=new HMGameMove();
        move.playerN=getUsername();
//        String[] turnMsgs={"Enter 1 to Move your Hero","Enter 2 to see your Stats"};
        String[] moveTurnMsgs = {"Enter W/w to move Up","Enter A/a to move Left","Enter S/s to move Down","Enter D/d to move Right","Enter I/i to see your hero stats","Enter P/p to consume Portion"};
        String[] mktMsg={"You have landed on a Market Place Block?","Do you want to enter the market place to Buy/Sell items","Enter M/m to Enter the Market Place","Enter N/n to Pass"};
        String[] invalidInputMsgs = {"Please enter a valid input..."};
        do{
            try {
                String inp=printer.getInput(moveTurnMsgs);
                if(inp.length()<1){
                    printer.displayMsgs(invalidInputMsgs);
                }
                if(inp.equalsIgnoreCase("q")){
                    move.quit=true;
                    break;
                }
                if(inp.equalsIgnoreCase("w")){
                    move.direction="Up";
                    break;
                }
                if(inp.equalsIgnoreCase("a")){
                    move.direction="Left";
                    break;
                }
                if(inp.equalsIgnoreCase("d")){
                    move.direction="Right";
                    break;
                }
                if(inp.equalsIgnoreCase("s")){
                    move.direction="Down";
                    break;
                }
                if(inp.equalsIgnoreCase("i")){
                    move.direction="Stats";
                    displayStats();
                    break;
                }
                if(inp.equalsIgnoreCase("p")){
                    move.direction="PortionConsume";
                    portionConsume(move);
                    break;
                }
                printer.displayMsgs(invalidInputMsgs);
            }
            catch(Exception e) {
               printer.displayMsgs(invalidInputMsgs);
            }

        }while(true);
        return move;
    }
    /*
    Input: GameMove object storing the information on a players move
    Outputs: N/A
    Function: Function to enable hero to consume portion
     */
    public void portionConsume(HMGameMove move){
        String[] heroCh={"Enter the hero you to consume Portion","Enter 0 to go back"};
        displayStats();
        do{
            try {
                String inp=printer.getInput(heroCh);
                int in=Integer.parseInt(inp);
                if(in==0){
                    System.out.println("Hope you have consumed the portion");
                    return;
                }
                if(in<1 && in>chosenHeroes.size()){
                    System.out.println("Please enter a number between 1 and "+chosenHeroes.size());
                    continue;
                }
                HMChosenHero chosenHero=chosenHeroes.get(in-1);
                chosenHero.consumePortion(move);
                System.out.println("Updated Stats:");
                displayStats();
                break;
            }
            catch (Exception e) {
                System.out.println("Invalid input!");
            }
        }while (true);
    }

    /*
    Input: N/A
    Outputs: N/A
    Function: Display stats of all heroes in the players party
     */
    public void displayStats(){
        System.out.println("Stats of All your Heroes");
        System.out.printf(
                "%-6s %-22s %-8s %-8s %-10s %-10s %-12s %-18s %-22s %-10s %-10s%n",
                "Index", "Hero", "Health", "Mana", "Strength", "Agility", "Dexterity",
                "Starting Money", "Starting Experience", "Level", "Type"
        );
        int k=1;
        for(HMChosenHero h:chosenHeroes){
            System.out.printf(
                    "%-6s %-22s %-8s %-8s %-10s %-10s %-12s %-18s %-22s %-10s %-10s%n",
                    k++,
                    h.name,
                    h.health,
                    h.mana,
                    h.strength,
                    h.agility,
                    h.dexterity,
                    h.money,
                    h.experience,
                    h.level,
                    h.heroType

            );
        }
        System.out.println("Monsters Defeated So Far ...");
        for(String s:defeatedMonsters){
            System.out.println(s);
        }
    }

    /*
    Input: N/A
    Outputs: maxHeroLevel (max level of hero in part)
    Function: Display stats of all heroes in the players party
     */
    public int getMaxHeroLevel(){
        int maxHeroLevel=0;
        for(int i=0;i<chosenHeroes.size();i++){
            if(chosenHeroes.get(i).level>maxHeroLevel){
                maxHeroLevel=chosenHeroes.get(i).level;
            }
        }
        return maxHeroLevel;
    }

    /*
    Input: MarketSpaceDealing marketSpaceDealing
    Outputs:
    Function: Display stats of all heroes in the players party
     */
    public boolean mktMove(MarketSpaceDealing marketSpaceDealing){
        String[] st=new  String[chosenHeroes.size()+1];
        for (int i = 0; i < chosenHeroes.size(); i++) {
            st[i]=("Enter " + (i+1) + " if you wish to enter the market with Hero " + chosenHeroes.get(i).name);
        }
        st[st.length-1]="Enter N/n to exit the Market";
        do {
            String inp=printer.getInput(st);
            if(inp.equalsIgnoreCase("n")){
                System.out.println("Leaving the Market");
                return true;
            }
            if(inp.equalsIgnoreCase("q")){
                return false;
            }
            try{
                int in =Integer.parseInt(inp);
                if(in<1 || in>chosenHeroes.size()){
                    System.out.println("Please enter a number between 1 and "+chosenHeroes.size()+".");
                    continue;
                }
                HMMarketGameMove move=new HMMarketGameMove();
                marketSpaceDealing.mktEnter(move,chosenHeroes.get(in-1));
                if(move.leaveMkt){
                    break;
                }
                if(move.quit){
                    break;
                }
            }
            catch(Exception e){
                System.out.println("Please enter a valid input...");
                continue;
            }
        }while (true);

        return true;
    }

    /*
    Input: (List<MonsterSpawn> monsterSpawns
    Outputs: boolean value on whether the post battle turn is completed or not
    Function: Stats update after heroes win the battle against monsters
     */
    public boolean wonBattleTurn(List<MonsterSpawn> monsterSpawns){
        for(MonsterSpawn m:monsterSpawns){
            defeatedMonsters.add(m.name);
        }
        for(HMChosenHero h:chosenHeroes){
            if(h.fainted){
                System.out.println("Reviving Hero "+h.name);
                h.money=h.money/2;
                h.mana=h.mana/2;
                h.health=(h.level*100)/2.0;
                h.fainted=false;
            }
            else{
                for(MonsterSpawn m:monsterSpawns){
                    h.money+=m.level*100;
                }
                h.experience+=monsterSpawns.size()*2;
                int newLvl=h.experience/3;
                if(newLvl>h.level){
                    System.out.println("Hero "+h.name+" has leveled Up!!!");
                    h.level=newLvl;
                    h.money+=h.level*50;
                    h.mana+=h.level*5;
                    h.health=h.level*100;
                    if(h.heroType.equals("Warriors")){
                        h.strength=(int)(h.strength*1.1);
                        h.agility=(int)(h.agility*1.1);
                        h.dexterity=(int)(h.dexterity*1.05);
                    }

                    if(h.heroType.equals("Paladins")){
                        h.strength=(int)(h.strength*1.1);
                        h.agility=(int)(h.agility*1.05);
                        h.dexterity=(int)(h.dexterity*1.1);
                    }

                    if(h.heroType.equals("Sorcerers")){
                        h.strength=(int)(h.strength*1.05);
                        h.agility=(int)(h.agility*1.1);
                        h.dexterity=(int)(h.dexterity*1.1);
                    }
                }
                else{
                    h.health=h.level*100;
                    h.mana= (int) (h.mana*1.2);
                }
            }

        }
        return  false;
    }

    /*
    Input: N/A
    Outputs: Number of monsters defeated
    Function: Stats update after heroes win the battle against monsters
     */
    public int getNumDefeatedMonsters(){
        return defeatedMonsters.size();
    }

    /*
    Input: Monsters m
    Outputs: Boolean value telling if monster is defeated or not
    Function: Tells whether a particular monster is defeated or not
     */
    public boolean notDefeated(Monsters m){
        for(String s:defeatedMonsters){
            if(s.equals(m.getName())){
                return false;
            }
        }
        return true;
    }
}
