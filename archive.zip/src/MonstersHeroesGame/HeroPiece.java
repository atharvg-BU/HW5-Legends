package MonstersHeroesGame;

import Parent.GamePiece;

public class HeroPiece extends GamePiece {
//    Class to store hero piece
    public HeroPiece(String icon){
        super(icon);
    }

}
