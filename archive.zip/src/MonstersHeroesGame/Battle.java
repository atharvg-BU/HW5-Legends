package MonstersHeroesGame;

public interface Battle {
    public HMBattleMove takeBattleTurn(HMBattleMove battleMove);
}
