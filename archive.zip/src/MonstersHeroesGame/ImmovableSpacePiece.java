package MonstersHeroesGame;

import Parent.GamePiece;

public class ImmovableSpacePiece extends GamePiece {
//   Class to store information on the immovable space piece marked by 'X'
    public ImmovableSpacePiece(String icon) {
        super(icon);
    }
}
