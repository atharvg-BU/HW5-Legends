package MonstersHeroesGame;

import Parent.GameMove;

public class HMGameMove extends GameMove {
//    Class to store information to game move specifically for the legends game
    public String moveString;
    public String playerN;
    public String direction;
    public boolean mktArr;
    public int playersOnSameTile;
}
