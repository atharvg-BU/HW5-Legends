package Parent;

public class GameMove {
//    Parent class to store basic information on the game move
    public String owner;
    public boolean quit;
}
