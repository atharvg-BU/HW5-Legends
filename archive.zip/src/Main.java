import Parent.SuperStarter;

public class Main {
//    Main function to start the program and let the user play the requested game
    public static void main(String[] args) {
        SuperStarter superStarter = new SuperStarter();
        superStarter.run();
    }
}
