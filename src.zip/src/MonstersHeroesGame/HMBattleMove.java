package MonstersHeroesGame;

import Parent.GameMove;

public class HMBattleMove extends GameMove {
//    Class to store information about a move made by either heroes or monsters during a battle
    public String opponent;
    public double hpDamage;
    public boolean selfHeal;
    public String weaponName;
}
